package Models;

public class User {
	class User extends Model {
	    private String name;
	    private String nim;
	    private String teamId;

	    public User(String name, String nim, String teamId) {
	        this.name = name;
	        this.nim = nim;
	        this.teamId = teamId;
	    }
	}
}