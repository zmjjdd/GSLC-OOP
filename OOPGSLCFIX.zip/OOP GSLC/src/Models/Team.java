package Models;

public class Team {
	class Team extends Model {
	    private String name;

	    public Team(String name) {
	        this.name = name;
	    }
	}
}
