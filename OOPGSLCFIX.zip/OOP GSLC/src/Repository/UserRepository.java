package Repository;

public class UserRepository {
	class UserRepository implements Repository<User> {
	    
	    public List<User> find(String column, String[] conditions, boolean joinTable, String joinTableName, Connection connection) {
	        List<User> users = new ArrayList<>();
	        try {
	            List<String[]> data = connection.readFile();
	            

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return users;
	    }

	    @Override
	    public User findOne(String column, String[] conditions, boolean joinTable, String joinTableName, Connection connection) {
	        List<User> users = find(column, conditions, joinTable, joinTableName, connection);
	        return users.isEmpty() ? null : users.get(0);
	    }

	    @Override
	    public User insert(String[] data, Connection connection) {
	        try {
	            List<String[]> currentData = connection.readFile();
	            int newId = currentData.size() + 1;
	            String[] newData = Arrays.copyOf(data, data.length + 1);
	            newData[data.length] = String.valueOf(newId);
	            currentData.add(newData);
	            connection.writeFile(currentData);

	            return new User(data[0], data[1], data[2]); 
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return null;
	    }
	}
}
