package Repository;

public class TeamRepository {
	class TeamRepository implements Repository<Team> {
	    @Override
	    public List<Team> find(String column, String[] conditions, boolean joinTable, String joinTableName, Connection connection) {
	        List<Team> teams = new ArrayList<>();
	        try {
	            List<String[]> data = connection.readFile();
	            

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return teams;
	    }

	    @Override
	    public Team findOne(String column, String[] conditions, boolean joinTable, String joinTableName, Connection connection) {
	        List<Team> teams = find(column, conditions, joinTable, joinTableName, connection);
	        return teams.isEmpty() ? null : teams.get(0);
	    }

	    @Override
	    public Team insert(String[] data, Connection connection) {
	        try {
	            List<String[]> currentData = connection.readFile();
	            int newId = currentData.size() + 1;
	            String[] newData = Arrays.copyOf(data, data.length + 1);
	            newData[data.length] = String.valueOf(newId);
	            currentData.add(newData);
	            connection.writeFile(currentData);

	            return new Team(data[0]); 
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return null;
	    }
	}
}
